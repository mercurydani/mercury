#!/usr/bin/env python3
"""Builds ../index.html for MercuryCode from the data below. Run: python3 tools/build.py"""
import json, pathlib, html

OUT = pathlib.Path(__file__).resolve().parent.parent / "index.html"
TG = "https://t.me/mercury_dani"
PHONE = "+381653454290"
PHONE_H = "+381 65 345 4290"

TRACKS = [
    {"id": "basics", "tab": "Основы компьютера", "age": "6–10 лет, с нуля", "title": "Основы компьютера",
     "meta": ["6 месяцев", "45 минут", "можно 1–2 месяца как подготовку"],
     "lead": "Для детей, которые раньше пользовались только телефоном или планшетом. Ребёнок уверенно работает с компьютером, печатает, делает документы и презентации, знает правила безопасности в интернете. Если нужна только подготовка, хватит первых 1–2 месяцев.",
     "months": [("Знакомство с компьютером", ["Из чего состоит компьютер", "Мышь: клик и перетаскивание", "Клавиатура: буквы, пробел, Enter"], "Проект: порядок на рабочем столе"),
                ("Файлы и папки", ["Что такое файл и папка", "Сохранить, переименовать, удалить", "Поиск файлов, флешка"], "Проект: своя папка-портфолио"),
                ("Печать и рисование", ["Клавиатурный тренажёр", "Печатаем слова и предложения", "Рисуем в Paint"], "Проект: открытка с подписью"),
                ("Документы", ["Текст и шрифты", "Картинки в документе", "Простая таблица"], "Проект: документ «Обо мне»"),
                ("Интернет и безопасность", ["Браузер, вкладки, адрес сайта", "Как искать информацию", "Пароли, незнакомцы, что не публиковать"], "Проект: доклад о любимом животном"),
                ("Презентации и первая логика", ["Слайды в презентации", "Анимация и переходы", "Первые логические игры на code.org"], "Защита: презентация перед родителями")]},
    {"id": "scratch", "tab": "Игры на Scratch", "age": "рекомендуем 7–9 лет", "title": "Игры на Scratch",
     "meta": ["6 месяцев", "45 минут", "цветные блоки, без сложного кода"],
     "lead": "Программа собирается из блоков, как конструктор. Ребёнок осваивает главные идеи программирования: циклы, условия, переменные, события. К концу курса придумывает свою игру с уровнями и публикует её.",
     "months": [("Оживляем героев", ["Интерфейс Scratch, первый спрайт", "Движение и повороты", "Костюмы и внешний вид"], "Проект: мультфильм-открытка"),
                ("Звук и истории", ["Звуки и музыка", "Диалоги, фоны и сцены", "Сообщения между спрайтами"], "Проект: интерактивная история"),
                ("Управление", ["События и нажатие клавиш", "Циклы", "Координаты и касания"], "Проект: игра-лабиринт"),
                ("Правила игры", ["Условия «если, то»", "Переменные: счёт", "Жизни, таймер, проигрыш"], "Проект: игра «Поймай предмет»"),
                ("Игры посложнее", ["Клоны", "Случайность и враги", "Несколько уровней"], "Проект: космическая стрелялка"),
                ("Своя игра", ["Идея и план своей игры", "Платформер: гравитация и прыжки", "Меню, звук, поиск ошибок"], "Защита: своя игра на Scratch")]},
    {"id": "web", "tab": "Свой сайт", "age": "рекомендуем 10–13 лет", "title": "Свой сайт: HTML, CSS, JavaScript",
     "meta": ["6 месяцев", "60 минут", "настоящий код"],
     "lead": "Ребёнок с нуля делает многостраничный сайт-портфолио, который работает на телефоне, добавляет в него интерактив на JavaScript и выкладывает в интернет по настоящей ссылке.",
     "months": [("Первая страница", ["Как устроены сайты, редактор VS Code", "Заголовки и абзацы", "Ссылки и картинки"], "Проект: страница «Обо мне»"),
                ("Структура сайта", ["Списки", "Таблицы", "Несколько страниц и меню"], "Проект: мини-сайт про хобби"),
                ("Оформление на CSS", ["Цвета, шрифты, фон", "Отступы, рамки, блоки", "Кнопки и эффекты при наведении"], "Проект: оформленный сайт"),
                ("Раскладка и адаптив", ["Flexbox", "Grid: галерея картинок", "Сайт на телефоне"], "Проект: сайт-портфолио"),
                ("JavaScript", ["Первый скрипт и консоль", "Переменные и условия", "Кнопки и события"], "Проект: викторина на сайте"),
                ("Свой проект", ["Мини-игра «кликер»", "Сохраняем результаты в браузере", "Публикация в интернете"], "Защита: свой сайт по ссылке")]},
    {"id": "python", "tab": "Python и Godot", "age": "рекомендуем 12–15 лет", "title": "Python и игра в Godot",
     "meta": ["6 месяцев", "60 минут", "язык, на котором работают в IT"],
     "lead": "4 месяца крепкой базы Python, одного из самых популярных языков в мире. Затем 2 месяца в игровом движке Godot: своя 2D-игра с уровнями, которую можно скинуть друзьям.",
     "months": [("Основы Python", ["Первая программа: print и input", "Переменные и числа", "Строки"], "Проект: программа-болталка"),
                ("Логика", ["Условия", "Цикл while", "Цикл for"], "Проект: «Угадай число»"),
                ("Данные и функции", ["Списки", "Функции", "Словари"], "Проект: текстовый квест"),
                ("Графика на turtle", ["Рисуем черепашкой", "Управление с клавиатуры", "Движение и столкновения"], "Проект: игра «Змейка»"),
                ("Первые шаги в Godot", ["Сцены и узлы", "GDScript и движение персонажа", "Физика, прыжки, столкновения"], "Проект: уровень платформера"),
                ("Своя игра", ["Враги и монеты", "Счёт, жизни, меню", "Звук, уровни, экспорт игры"], "Защита: своя игра на itch.io")]},
]
DEFAULT = "scratch"

WHO = [("Любит игры", "и хочет не только играть, но и сделать свою."),
       ("Много времени за экраном", "Направим это время в полезный навык."),
       ("Новичок", "Опыт не нужен, каждая программа начинается с основ."),
       ("Русскоязычные семьи в Сербии", "Сложные темы проще понять на родном языке.")]

LESSON = [("Разминка", "Вспоминаем прошлый урок, решаем мини-загадку."),
          ("Новая тема", "Коротко и на живом примере, без долгих лекций."),
          ("Практика", "Большая часть урока: ребёнок сам пишет и пробует."),
          ("Результат", "Показывает, что получилось. Каждый урок заканчивается готовой частью проекта.")]

TEACHER = [("Опыт преподавания", "Преподаватель программирования в колледже"),
           ("Образование", "Среднее профессиональное (СПО), диплом по программированию"),
           ("Учёба сейчас", "Получаю высшее по направлению «Прикладная информатика»"),
           ("Практика", "Около 3 лет в IT, делаю сайты и игры на Godot")]

FAQ = [("Ребёнок никогда не программировал. Это не страшно?", "Нет, все программы начинаются с нуля. Если ребёнок уже что-то умеет, подберу задания посложнее."),
       ("Можно выбрать программу не по возрасту?", "Да. Возраст только ориентир. Если девятилетний хочет делать сайты, а двенадцатилетний начать со Scratch, подстроим темп."),
       ("Что будет после полугода?", "Можно продолжить: в Scratch делаем платформеры и игры с уровнями, в веб-программе сайты с JavaScript, в Python игры побольше и основы pygame. Или перейти в другое направление."),
       ("Как родители видят прогресс?", "Каждый месяц ребёнок показывает готовый проект, а я коротко рассказываю, что получилось и над чем поработать."),
       ("Что нужно для занятий?", "Только ноутбук или компьютер. Все программы бесплатные, помогу установить на первом уроке."),
       ("Сколько стоит урок?", "Пробный урок бесплатно. Разовый урок 2 800 RSD. По абонементу 2 500 RSD за урок при занятиях раз в неделю и 2 250 RSD при двух уроках в неделю. Мини-группа 6 000 RSD в месяц."),
       ("Занятия онлайн или вживую?", "Сейчас онлайн через Zoom или Google Meet, из любого города Сербии и не только. Мини-группы в Белграде и выезд к вам домой скоро.")]

e = html.escape


def track_html(t):
    on = t["id"] == DEFAULT
    months = []
    for i, (name, lessons, proj) in enumerate(t["months"]):
        n0 = i * 4 + 1
        lis = "".join(f"<li><span class=\"no\">{n0 + k}</span>{e(l)}</li>" for k, l in enumerate(lessons))
        lis += f'<li class="proj"><span class="no">{n0 + 3}</span>{e(proj)}</li>'
        months.append(f'<li class="mo{" last" if i == 5 else ""}"><p class="mo-n">Месяц {i + 1}</p><h4>{e(name)}</h4><ol>{lis}</ol></li>')
    meta = "".join(f"<li>{e(m)}</li>" for m in t["meta"])
    return f'''
      <div class="track" id="t-{t["id"]}" role="tabpanel" aria-labelledby="tab-{t["id"]}"{"" if on else " hidden"}>
        <div class="track-top">
          <h3>{e(t["title"])}</h3>
          <ul class="chips">{meta}</ul>
        </div>
        <p class="track-lead">{e(t["lead"])}</p>
        <ol class="months">{"".join(months)}</ol>
      </div>'''


tabs = "".join(
    f'<button type="button" role="tab" id="tab-{t["id"]}" aria-controls="t-{t["id"]}" aria-selected="{"true" if t["id"] == DEFAULT else "false"}"{"" if t["id"] == DEFAULT else " tabindex=\"-1\""}><b>{e(t["tab"])}</b><span>{e(t["age"])}</span></button>'
    for t in TRACKS)
tracks = "".join(track_html(t) for t in TRACKS)
who = "".join(f"<li><h3>{e(a)}</h3><p>{e(b)}</p></li>" for a, b in WHO)
lesson = "".join(f'<li><p class="st">{i + 1}</p><h3>{e(a)}</h3><p>{e(b)}</p></li>' for i, (a, b) in enumerate(LESSON))
teacher = "".join(f"<div><dt>{e(a)}</dt><dd>{e(b)}</dd></div>" for a, b in TEACHER)
faq = "".join(f"<details><summary>{e(q)}</summary><p>{e(a)}</p></details>" for q, a in FAQ)

BASE = "https://mercurystudio.pro/education/"
MIN = {"basics": 45, "scratch": 45, "web": 60, "python": 60}
ld = {"@context": "https://schema.org", "@graph": [
    {"@type": "EducationalOrganization", "@id": BASE + "#org", "name": "MercuryCode", "url": BASE,
     "description": "Курсы программирования для детей 6–15 лет на русском языке, онлайн и в Белграде.",
     "image": BASE + "og.jpg", "logo": "https://mercurystudio.pro/favicon-96.png",
     "telephone": PHONE, "sameAs": [TG], "areaServed": [{"@type": "City", "name": "Beograd"}, {"@type": "Country", "name": "Srbija"}],
     "knowsLanguage": "ru", "taxID": "116017500",
     "address": {"@type": "PostalAddress", "addressLocality": "Beograd", "addressCountry": "RS"},
     "parentOrganization": {"@type": "Organization", "name": "Mercury Studio", "url": "https://mercurystudio.pro/"},
     "founder": {"@type": "Person", "@id": BASE + "#teacher", "name": "Даниил Помазков", "alternateName": "Daniil Pomazkov", "jobTitle": "Преподаватель программирования"}},
    {"@type": "WebPage", "@id": BASE + "#page", "url": BASE, "inLanguage": "ru", "name": "Программирование для детей на русском, Белград",
     "about": {"@id": BASE + "#org"}, "primaryImageOfPage": BASE + "og.jpg",
     "breadcrumb": {"@type": "BreadcrumbList", "itemListElement": [
         {"@type": "ListItem", "position": 1, "name": "Mercury Studio", "item": "https://mercurystudio.pro/ru/"},
         {"@type": "ListItem", "position": 2, "name": "Программирование для детей", "item": BASE}]}},
    *[{"@type": "Course", "@id": BASE + "#" + t["id"], "name": t["title"], "description": t["lead"], "inLanguage": "ru",
       "educationalLevel": "Beginner", "typicalAgeRange": {"basics": "6-10", "scratch": "7-9", "web": "10-13", "python": "12-15"}[t["id"]],
       "teaches": [m[0] for m in t["months"]], "provider": {"@id": BASE + "#org"},
       "hasCourseInstance": {"@type": "CourseInstance", "courseMode": "online", "inLanguage": "ru", "instructor": {"@id": BASE + "#teacher"},
                             "courseWorkload": "PT%dH" % (24 * MIN[t["id"]] // 60)},
       "offers": [{"@type": "Offer", "name": "Разовый урок", "price": 2800, "priceCurrency": "RSD", "category": "Paid"},
                  {"@type": "Offer", "name": "1 раз в неделю, месяц", "price": 10000, "priceCurrency": "RSD", "category": "Subscription"},
                  {"@type": "Offer", "name": "2 раза в неделю, месяц", "price": 18000, "priceCurrency": "RSD", "category": "Subscription"}]} for t in TRACKS],
    {"@type": "FAQPage", "@id": BASE + "#faq", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ]},
]}

page = (pathlib.Path(__file__).parent / "template.html").read_text(encoding="utf-8")
page = (page.replace("{{TABS}}", tabs).replace("{{TRACKS}}", tracks).replace("{{WHO}}", who)
        .replace("{{LESSON}}", lesson).replace("{{TEACHER}}", teacher).replace("{{FAQ}}", faq)
        .replace("{{LD}}", json.dumps(ld, ensure_ascii=False, separators=(",", ":")))
        .replace("{{TG}}", TG).replace("{{PHONE}}", PHONE).replace("{{PHONE_H}}", PHONE_H))
OUT.write_text(page, encoding="utf-8")
print("wrote", OUT, len(page), "bytes")

# the same page lives on the studio site at /education/
STUDIO = OUT.parent.parent / "mercury-studio" / "education"
if STUDIO.parent.is_dir():
    import shutil
    STUDIO.mkdir(exist_ok=True)
    (STUDIO / "index.html").write_text(page, encoding="utf-8")
    shutil.copy(OUT.parent / "og.jpg", STUDIO / "og.jpg")
    print("wrote", STUDIO / "index.html")
